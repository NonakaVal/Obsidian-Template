---
banner: https://w.wallhaven.cc/full/7j/wallhaven-7jgyre.jpg
cssclasses:
  - hide-properties_reading
---


Anote alguma coisa, [[crie um link]] ou pelo atalho `ctrl + N` , Toda nota é criada inicialmente da pasta `+`.   ou :LiArrowBigRight:  `BUTTON[new-note]`  ou Seguir :LiArrowBigRight: `BUTTON[workspaces]` 




```meta-bind-button
label: Sessões de Introdução
hidden: true
icon: space
class: ""
id: workspaces
style: destructive
actions:
  - type: command
    command: workspaces:load
```






<br><br><br><br>

`BUTTON[hotkeys]`



   



```meta-bind-button
label: Nova Nota
hidden: true
icon: plus
class: ""
id: new-note
style: primary
actions:
  - type: command
    command: quickadd:choice:3edf5ca1-598e-42e8-beec-fe2714a9a1f9
```


```meta-bind-button
label: Atalhos
hidden: true
icon: keyboard
class: ""
id: hotkeys
style: primary
actions:
  - type: command
    command: obsidian-hotkeys-for-specific-files:X/Assets/_atalhos.md-new-tab
```


[^1]: Atalho `Alt + W` para acessar Workspaces
