---
cssclasses:
  - wide-page
  - imagegallery
---
%%  %%
<div align="center">

[![CLIQUE PARA ACESSAR](https://img.shields.io/badge/⬇️_BAIXAR_VERSÃO_PRO-8b5cf6?style=for-the-badge&logo=rocket&logoColor=white)](obsidian://open?vault=MyVault%20Pro)

<small>*Sistema premium com recursos exclusivos*</small>

</div>

<br>


[[showcase]]