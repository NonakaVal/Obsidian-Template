
```meta-bind-button
label: (Tópicos em Ordem)
hidden: false
icon: space
class: ""
id: workspaces
style: destructive
actions:
  - type: command
    command: workspaces:load
```
