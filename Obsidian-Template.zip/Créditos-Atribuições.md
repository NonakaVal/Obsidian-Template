---
dg-publish: true
---
# Créditos/Atribuições

- https://github.com/DuskWasHere/dusk-obsidian-vault
- https://fortelabs.com/blog/para/
- [Dashboard ++](https://github.com/TfTHacker/DashboardPlusPlus)
- https://github.com/TfTHacker/journal-craft-obsidian
- https://forum.obsidian.md/t/linking-your-thinking-resources/6177
- ACE para Organização, Pacote de Conhecimento" (Versão 1.0) de Nick Milo & LYT, licenciado sob CC BY-NC-ND 4.0.
	- Criado por: [Nick Milo](https://www.youtube.com/@linkingyourthinking)
	- [Linking Your Thinking - Nick Milo](https://www.linkingyourthinking.com/)

# Licença/Termos de Uso

Este pacote está licenciado sob a licença **Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International (CC BY-NC-ND 4.0)**.

Agradecimentos especiais: À comunidade inicial do Obsidian.
# Outros Recursos 

>    Meu canal Youtube
> - [Um resumo sobre aprender com Anotações 1](https://www.youtube.com/watch?v=cQ22PERTCBI&t=3s)
> - [Um resumo sobre aprender com Anotações 2](https://www.youtube.com/watch?v=aMFggmPRiio)
> - [Fundamentos PKM](https://www.youtube.com/watch?v=o1laZYM9k8A&t=25s)
> - [10 Dicas Básicas de Obsidian](https://www.youtube.com/watch?v=8MXjWNNrYDw&t=1s)
> - [Tudo sobre como estilizar sua vault](https://www.youtube.com/watch?v=pxHNu7vJzRc&t=34s)
> - [Como usar o melhor dashboard da comunidade de obsidian](https://www.youtube.com/watch?v=HIqwsECT7vI&t=12s)
> - [Plugins que deveriam ser nativos no obsidian](https://www.youtube.com/watch?v=Bqf2wV_DzKE&t=5s)
> - [Plugins da comunidade ](https://www.youtube.com/watch?v=LcuK-229btQ&t=34s)
> - [Sobre COMO organizar suas PASTAS](https://www.youtube.com/watch?v=zCnEA2uSC0g&t=11s)
> - [A melhor forma de fazer backup das suas notas](https://www.youtube.com/watch?v=ZyK2vylCLL4&t=8s)
> - [As duas formas que uso templates](https://www.youtube.com/watch?v=d2gZtHTnVL4&t=10s)
> - [Como eu uso dataview](https://www.youtube.com/watch?v=sN8n62w8fdo&t=57s)

>   Outros canais recomendados ⭐
> https://www.youtube.com/@nicolevdh
> https://www.youtube.com/@linkingyourthinking
> https://www.youtube.com/@FromSergio


# Considere Apoiar meu projeto

<a href="https://www.buymeacoffee.com/nonakaval" target="_blank"><img src="https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png" alt="Buy Me A Coffee" style="height: 41px !important;width: 174px !important;box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;-webkit-box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;" ></a>