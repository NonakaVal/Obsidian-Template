
#  Considere apoiar o projeto e Acessar meu grupo 💛

<div style="display:flex; gap:12px; align-items:center; flex-wrap:wrap;">

<a href="https://wa.me/5515998304344?text=Gostaria%20de%20saber%20mais%20sobre%20seus%20templates%20obsidian" target="_blank">
  <img src="https://img.shields.io/badge/🛒%20saber%20mais%20sobre-43A047?style=for-the-badge&logo=whatsapp&logoColor=white" />
</a>

<a href="https://www.buymeacoffee.com/nonakaval" target="_blank">
  <img src="https://img.shields.io/badge/☕%20Apoiar%20no%20Buy%20Me%20a%20Coffee-FF813F?style=for-the-badge&logo=buymeacoffee&logoColor=white" />
</a>

</div>


