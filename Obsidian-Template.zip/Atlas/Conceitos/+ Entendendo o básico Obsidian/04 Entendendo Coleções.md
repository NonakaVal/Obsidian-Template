---
collection: "[[+ Gestão de Conhecimento]]"
---
As **coleções** são um sistema de **agrupamento temático** que funciona através de **referências bidirecionais** no Obsidian. Uma coleção é uma **nota central no [[How folder System Works|sistema]]**, vazia **ou** não, que automaticamente exibe todas as notas que fazem referência a ela através da propriedade `collection:`.

Ficam em `Sistema/Coleções/` e servem como "etiquetas inteligentes".

Nota de controle das coleções 🔗 [[@_collections]].

<br><br>

---

 Seguir para ➡️ [[06 Boas Práticas de Classificação]]

